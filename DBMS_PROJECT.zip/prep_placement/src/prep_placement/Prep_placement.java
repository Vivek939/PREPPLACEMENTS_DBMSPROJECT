/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prep_placement;

/**
 *
 * @author vivek
 */
public class Prep_placement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MainScreen m=new MainScreen();
        m.setVisible(true);
    }
    
}
